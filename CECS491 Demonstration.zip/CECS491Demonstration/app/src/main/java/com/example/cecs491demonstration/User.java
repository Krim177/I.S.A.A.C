package com.example.cecs491demonstration;

public class User {

    private String name,email,username,password,userId;

    public User(){

    }

    public User(String name, String email, String username, String password, String userId) {
        this.name = name;
        this.email = email;
        this.username = username;
        this.password = password;
        this.userId = userId;
    }
}
